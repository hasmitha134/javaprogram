package studyopedia;

public class demo {

	public static void main(String[] args) {
		System.out.println("this is first java class");
		int num =8;
		for(int i=1; i<=num;i++);
		if(num%2==0)
		{
			System.out.println("number is even");
		}
		else
		{
			System.out.println("number is odd");
		}
		
		// TODO Auto-generated method stub


	}

}
