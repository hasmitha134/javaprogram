package studyopedia;

public class Demo4 {
	static int add(int x,int y)
	{
		return x+y;
	}
	static int sub(int x,int y)
	{
		return x-y;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("my first java program");
		System.out.println(add(5,3));
		System.out.println(sub(20,12));
		
		
	}

}
